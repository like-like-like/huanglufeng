package com.bruceliu.service.impl;

import com.bruceliu.mapper.ClassMapper;
import com.bruceliu.pojo.Class;
import com.bruceliu.service.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/12 10:32
 * @QQ:1241488705
 * @Description:
 */
@Service
public class ClassServiceImpl implements ClassService {

    @Autowired
    ClassMapper classMapper;

    @Override
    public List<Class> getClasses() {
        return classMapper.getClasses();
    }
}
