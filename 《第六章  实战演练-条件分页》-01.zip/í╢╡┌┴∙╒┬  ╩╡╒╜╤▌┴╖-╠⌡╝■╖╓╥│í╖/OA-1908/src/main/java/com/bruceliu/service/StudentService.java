package com.bruceliu.service;

import com.bruceliu.pojo.Student;

import java.util.List;
import java.util.Map;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/12 10:02
 * @QQ:1241488705
 * @Description:
 */
public interface StudentService {

    /**
     * 01-查询总数
     * @return
     */
    public int getTotalCount(Map<String,Object> map);

    /**
     * 02-查询每页数据
     * @return
     */
    public List<Student> getStudents(Map<String,Object> map);
}
