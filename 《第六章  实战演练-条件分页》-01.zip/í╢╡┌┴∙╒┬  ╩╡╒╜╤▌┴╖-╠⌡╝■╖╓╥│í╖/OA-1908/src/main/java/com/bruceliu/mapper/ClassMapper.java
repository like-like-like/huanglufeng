package com.bruceliu.mapper;

import com.bruceliu.pojo.Class;

import java.util.List;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/12 10:29
 * @QQ:1241488705
 * @Description:
 */
public interface ClassMapper {

    public List<Class> getClasses();
}
