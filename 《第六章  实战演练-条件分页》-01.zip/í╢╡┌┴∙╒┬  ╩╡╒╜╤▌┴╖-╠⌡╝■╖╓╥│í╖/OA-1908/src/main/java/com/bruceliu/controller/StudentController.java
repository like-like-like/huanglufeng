package com.bruceliu.controller;

import com.bruceliu.pojo.Class;
import com.bruceliu.pojo.Student;
import com.bruceliu.service.ClassService;
import com.bruceliu.service.StudentService;
import com.bruceliu.utils.PageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/12 10:03
 * @QQ:1241488705
 * @Description:
 */
@Controller
@Scope("prototype")
public class StudentController {

    @Autowired
    StudentService studentService;

    @Autowired
    ClassService classService;

    @ResponseBody
    @RequestMapping("/student_getClasses")
    public List<Class> getClasses(){
        return classService.getClasses();
    }

    @RequestMapping("/student_list/{pageIndex}/{pageSize}")
    public String getStudents(@PathVariable("pageIndex") Long pageIndex, @PathVariable("pageSize") Long pageSize, @RequestParam(value = "name",defaultValue = "") String name, @RequestParam(value = "classId",defaultValue = "0") long classId, Model model){

        Map<String,Object> map=new HashMap<String,Object>();
        map.put("pageStart",(pageIndex-1)*pageSize);
        map.put("pageSize",pageSize);
        map.put("classId",classId);
        map.put("name","%"+name+"%");

        int totalCount = studentService.getTotalCount(map);
        List<Student> students = studentService.getStudents(map);

        //封装一个分页的工具类
        PageUtils pageUtils=new PageUtils(pageIndex,pageSize,totalCount,students);
        model.addAttribute("pageUtils",pageUtils);
        //条件需要回显
        model.addAttribute("name",name);
        model.addAttribute("classId",classId);
        return "studentlist";

    }



}
