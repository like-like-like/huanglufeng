package com.bruceliu.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Class {

  private long id;
  private long majorId;
  private String className;
  private String classDate;
  private String classTime;
  private String classAddress;
  private long classDelete;

}
