package com.bruceliu.service;

import com.bruceliu.pojo.Emp;
import com.bruceliu.utils.TongJi;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/9 11:04
 * @QQ:1241488705
 * @Description:
 */
public interface EmpService {

    /**
     * 01-登录
     * @return
     */
    public Emp login(Emp emp);


    public int addEmp(Emp emp);

    /**
     * 02-查询总数
     * @return
     */
    public int getTotalCount();

    /**
     * 03-查询每页数据
     * @return
     */
    public List<Emp> getEmps(@Param("pageStart") long pageStart, @Param("pageSize") long pageSize);

    /**
     * 报表数据统计
     * @return
     */
    public List<TongJi> getEmpsTongji();
}
