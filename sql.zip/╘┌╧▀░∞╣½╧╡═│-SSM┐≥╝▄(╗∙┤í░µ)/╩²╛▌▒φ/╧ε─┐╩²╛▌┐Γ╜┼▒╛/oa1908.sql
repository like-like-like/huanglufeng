/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50521
Source Host           : localhost:3306
Source Database       : oa1908

Target Server Type    : MYSQL
Target Server Version : 50521
File Encoding         : 65001

Date: 2020-02-24 11:39:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_class
-- ----------------------------
DROP TABLE IF EXISTS `t_class`;
CREATE TABLE `t_class` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `major_id` int(6) DEFAULT NULL,
  `class_name` varchar(30) DEFAULT NULL,
  `class_date` date DEFAULT NULL,
  `class_time` varchar(30) DEFAULT NULL,
  `class_address` varchar(30) DEFAULT NULL,
  `class_delete` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_major_id_01` (`major_id`),
  CONSTRAINT `FK_major_id_01` FOREIGN KEY (`major_id`) REFERENCES `t_major` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_class
-- ----------------------------
INSERT INTO `t_class` VALUES ('1', '1', '物联网班', '2019-08-08', '50', '19楼1教室', '0');
INSERT INTO `t_class` VALUES ('2', '2', '商务外语班', '2019-08-07', '60', '19楼2教室', '0');
INSERT INTO `t_class` VALUES ('4', '3', 'JAVA基础班', '2019-12-13', '500', '19楼9教室', '0');
INSERT INTO `t_class` VALUES ('5', '3', 'H5前端班', '2019-11-27', '400', '18楼9教室', '0');
INSERT INTO `t_class` VALUES ('6', '3', 'JAVA架构师班', '2019-12-17', '400', '成都', '0');
INSERT INTO `t_class` VALUES ('7', '1', '测试班级', '2010-10-10', '200', '成都', '0');
INSERT INTO `t_class` VALUES ('8', '1', '测试班级', '2010-10-10', '200', '成都', '0');
INSERT INTO `t_class` VALUES ('10', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('11', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('12', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('13', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('14', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('15', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('16', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('17', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('18', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('19', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('20', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('21', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('22', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('23', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('24', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('25', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('26', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('27', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('28', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('29', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('30', '2', null, '2010-10-10', '', '', '0');
INSERT INTO `t_class` VALUES ('31', '1', '测试134', '2019-12-18', '213', '435345', '0');
INSERT INTO `t_class` VALUES ('32', '1', null, '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('33', '1', null, '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('34', '1', '哈哈哈422', '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('35', '1', '哈哈哈422', '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('36', '1', '     ', '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('37', '1', '546456', '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('38', '1', '546456', '2010-10-10', null, null, '0');
INSERT INTO `t_class` VALUES ('39', '1', '21323', '2019-12-17', '234', '234324', '0');
INSERT INTO `t_class` VALUES ('40', '1', '5467', '2019-12-17', '456', '4564', '0');
INSERT INTO `t_class` VALUES ('41', '1', '54672342', '2019-12-19', '456', '4564', '0');
INSERT INTO `t_class` VALUES ('42', '1', '324432424', '2019-12-20', '234', '234', '0');
INSERT INTO `t_class` VALUES ('43', '2', '1111555', '2019-12-20', '345', '3453', '0');

-- ----------------------------
-- Table structure for t_depart
-- ----------------------------
DROP TABLE IF EXISTS `t_depart`;
CREATE TABLE `t_depart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `createtime` date DEFAULT NULL,
  `del` int(14) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=325 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_depart
-- ----------------------------
INSERT INTO `t_depart` VALUES ('1', '教学部', '2018-06-27', '0');
INSERT INTO `t_depart` VALUES ('2', '就业部', '2018-06-27', '0');
INSERT INTO `t_depart` VALUES ('3', '后勤部', '2019-12-10', '0');
INSERT INTO `t_depart` VALUES ('4', '财务部', '2019-12-10', '0');
INSERT INTO `t_depart` VALUES ('5', '部门测试1', '2019-12-10', '0');
INSERT INTO `t_depart` VALUES ('6', '部门测试2', '2019-12-10', '0');
INSERT INTO `t_depart` VALUES ('105', '售后部', '2019-12-11', '0');
INSERT INTO `t_depart` VALUES ('106', '归宅部', '2019-12-12', '0');
INSERT INTO `t_depart` VALUES ('107', '奥利给', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('108', '天海翼', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('109', '游戏部门', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('110', '麻生希', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('111', '4396', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('112', '修神部', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('113', '小泽', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('114', '安保部', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('115', '波多', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('116', '天龙八部', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('117', '麻生希', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('118', '同学们不要删我部门', '2019-12-12', '1');
INSERT INTO `t_depart` VALUES ('119', '精神小伙', '2019-12-12', '0');
INSERT INTO `t_depart` VALUES ('120', '波多野结衣', '2019-12-13', '1');
INSERT INTO `t_depart` VALUES ('121', '天海翼', '2019-12-13', '0');
INSERT INTO `t_depart` VALUES ('122', '神波多一花', '2019-12-13', '0');
INSERT INTO `t_depart` VALUES ('123', '嘤嘤嘤', '2019-12-13', '0');
INSERT INTO `t_depart` VALUES ('124', '会计部', '2019-12-18', '0');
INSERT INTO `t_depart` VALUES ('125', '部门测试1', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('126', '部门测试2', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('127', '部门测试3', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('128', '部门测试4', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('129', '部门测试5', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('130', '部门测试6', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('131', '部门测试7', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('132', '部门测试8', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('133', '部门测试9', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('134', '部门测试10', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('135', '部门测试11', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('136', '部门测试12', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('137', '部门测试13', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('138', '部门测试14', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('139', '部门测试15', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('140', '部门测试16', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('141', '部门测试17', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('142', '部门测试18', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('143', '部门测试19', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('144', '部门测试20', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('145', '部门测试21', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('146', '部门测试22', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('147', '部门测试23', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('148', '部门测试24', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('149', '部门测试25', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('150', '部门测试26', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('151', '部门测试27', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('152', '部门测试28', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('153', '部门测试29', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('154', '部门测试30', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('155', '部门测试31', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('156', '部门测试32', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('157', '部门测试33', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('158', '部门测试34', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('159', '部门测试35', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('160', '部门测试36', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('161', '部门测试37', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('162', '部门测试38', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('163', '部门测试39', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('164', '部门测试40', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('165', '部门测试41', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('166', '部门测试42', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('167', '部门测试43', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('168', '部门测试44', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('169', '部门测试45', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('170', '部门测试46', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('171', '部门测试47', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('172', '部门测试48', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('173', '部门测试49', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('174', '部门测试50', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('175', '部门测试51', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('176', '部门测试52', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('177', '部门测试53', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('178', '部门测试54', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('179', '部门测试55', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('180', '部门测试56', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('181', '部门测试57', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('182', '部门测试58', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('183', '部门测试59', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('184', '部门测试60', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('185', '部门测试61', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('186', '部门测试62', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('187', '部门测试63', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('188', '部门测试64', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('189', '部门测试65', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('190', '部门测试66', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('191', '部门测试67', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('192', '部门测试68', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('193', '部门测试69', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('194', '部门测试70', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('195', '部门测试71', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('196', '部门测试72', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('197', '部门测试73', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('198', '部门测试74', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('199', '部门测试75', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('200', '部门测试76', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('201', '部门测试77', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('202', '部门测试78', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('203', '部门测试79', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('204', '部门测试80', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('205', '部门测试81', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('206', '部门测试82', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('207', '部门测试83', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('208', '部门测试84', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('209', '部门测试85', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('210', '部门测试86', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('211', '部门测试87', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('212', '部门测试88', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('213', '部门测试89', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('214', '部门测试90', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('215', '部门测试91', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('216', '部门测试92', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('217', '部门测试93', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('218', '部门测试94', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('219', '部门测试95', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('220', '部门测试96', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('221', '部门测试97', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('222', '部门测试98', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('223', '部门测试99', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('224', '部门测试100', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('225', '部门测试1', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('226', '部门测试2', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('227', '部门测试3', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('228', '部门测试4', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('229', '部门测试5', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('230', '部门测试6', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('231', '部门测试7', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('232', '部门测试8', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('233', '部门测试9', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('234', '部门测试10', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('235', '部门测试11', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('236', '部门测试12', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('237', '部门测试13', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('238', '部门测试14', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('239', '部门测试15', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('240', '部门测试16', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('241', '部门测试17', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('242', '部门测试18', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('243', '部门测试19', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('244', '部门测试20', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('245', '部门测试21', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('246', '部门测试22', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('247', '部门测试23', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('248', '部门测试24', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('249', '部门测试25', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('250', '部门测试26', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('251', '部门测试27', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('252', '部门测试28', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('253', '部门测试29', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('254', '部门测试30', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('255', '部门测试31', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('256', '部门测试32', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('257', '部门测试33', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('258', '部门测试34', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('259', '部门测试35', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('260', '部门测试36', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('261', '部门测试37', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('262', '部门测试38', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('263', '部门测试39', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('264', '部门测试40', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('265', '部门测试41', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('266', '部门测试42', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('267', '部门测试43', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('268', '部门测试44', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('269', '部门测试45', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('270', '部门测试46', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('271', '部门测试47', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('272', '部门测试48', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('273', '部门测试49', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('274', '部门测试50', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('275', '部门测试51', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('276', '部门测试52', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('277', '部门测试53', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('278', '部门测试54', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('279', '部门测试55', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('280', '部门测试56', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('281', '部门测试57', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('282', '部门测试58', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('283', '部门测试59', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('284', '部门测试60', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('285', '部门测试61', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('286', '部门测试62', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('287', '部门测试63', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('288', '部门测试64', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('289', '部门测试65', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('290', '部门测试66', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('291', '部门测试67', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('292', '部门测试68', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('293', '部门测试69', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('294', '部门测试70', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('295', '部门测试71', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('296', '部门测试72', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('297', '部门测试73', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('298', '部门测试74', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('299', '部门测试75', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('300', '部门测试76', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('301', '部门测试77', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('302', '部门测试78', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('303', '部门测试79', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('304', '部门测试80', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('305', '部门测试81', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('306', '部门测试82', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('307', '部门测试83', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('308', '部门测试84', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('309', '部门测试85', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('310', '部门测试86', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('311', '部门测试87', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('312', '部门测试88', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('313', '部门测试89', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('314', '部门测试90', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('315', '部门测试91', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('316', '部门测试92', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('317', '部门测试93', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('318', '部门测试94', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('319', '部门测试95', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('320', '部门测试96', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('321', '部门测试97', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('322', '部门测试98', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('323', '部门测试99', '2019-12-25', '0');
INSERT INTO `t_depart` VALUES ('324', '部门测试100', '2019-12-25', '0');

-- ----------------------------
-- Table structure for t_emp
-- ----------------------------
DROP TABLE IF EXISTS `t_emp`;
CREATE TABLE `t_emp` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `no` varchar(20) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `did` int(11) DEFAULT NULL COMMENT '外键  部门ID',
  `flag` int(11) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `qq` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `createdate` date DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `del` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DID` (`did`),
  CONSTRAINT `FK_DID` FOREIGN KEY (`did`) REFERENCES `t_depart` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_emp
-- ----------------------------
INSERT INTO `t_emp` VALUES ('1', '1108888', '21312312', '鲁涛2', '1', '1', '男', '1774753691@qq.com', '222321', '110', '2018-03-03', '2019-11-20 14:42:29', '4354.jpg', '0');
INSERT INTO `t_emp` VALUES ('2', '1234', '1234', '鲁涛1', '1', '1', '男', '562234836@qq.com', '34543534', '1334564645', '2019-12-27', '2019-09-10 14:42:34', '23432.jpg', '0');
INSERT INTO `t_emp` VALUES ('3', '1234588', '43534', '小泽', '3', '1', '女', '729274446@qq.com', '4564567546', '13453443543', '2019-12-11', '2019-09-10 14:42:40', 'da0091f1-725f-4a8f-ac7c-0dccabce1fb7.jpg', '0');
INSERT INTO `t_emp` VALUES ('4', '9527888', '456456', '星星', '2', '1', '男', '1346806562@qq.com', '34543543', '134534545345', '2019-12-16', '2019-08-14 14:42:47', 'dd415302-0511-43ee-bfc3-62d084aac895.jpg', '0');
INSERT INTO `t_emp` VALUES ('50', 'admin', 'admin123', '星星11', '120', '1', '女', '83474804@qq.com', '65461561', '132154', '2019-12-17', '2019-12-20 14:38:57', 'a2e5ec65-cb9d-455d-a0fc-812069cf64b2.jpg', '0');

-- ----------------------------
-- Table structure for t_emp_role
-- ----------------------------
DROP TABLE IF EXISTS `t_emp_role`;
CREATE TABLE `t_emp_role` (
  `emp_role_id` int(6) NOT NULL AUTO_INCREMENT,
  `emp_id` int(6) DEFAULT NULL,
  `role_id` int(6) DEFAULT NULL,
  PRIMARY KEY (`emp_role_id`),
  KEY `fk_emp_id` (`emp_id`),
  KEY `fk_role_id` (`role_id`),
  CONSTRAINT `fk_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `t_emp` (`id`),
  CONSTRAINT `fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `t_role` (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_emp_role
-- ----------------------------
INSERT INTO `t_emp_role` VALUES ('1', '1', '1');
INSERT INTO `t_emp_role` VALUES ('3', '2', '4');
INSERT INTO `t_emp_role` VALUES ('4', '3', '3');
INSERT INTO `t_emp_role` VALUES ('5', '4', '1');
INSERT INTO `t_emp_role` VALUES ('6', '4', '4');

-- ----------------------------
-- Table structure for t_loginlog
-- ----------------------------
DROP TABLE IF EXISTS `t_loginlog`;
CREATE TABLE `t_loginlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) DEFAULT NULL,
  `no` varchar(20) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `location` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_loginlog
-- ----------------------------
INSERT INTO `t_loginlog` VALUES ('1', '117.159.15.221', 'admin', '2018-07-12 14:04:49', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('2', '117.159.15.221', 'admin', '2018-07-12 16:02:08', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('3', '117.159.15.221', 'admin', '2018-07-12 16:05:00', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('4', '117.159.15.221', 'admin', '2018-07-12 16:13:30', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('5', '117.159.15.221', 'admin', '2018-07-12 16:14:36', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('6', '117.159.15.221', 'admin', '2018-07-12 16:23:53', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('7', '117.159.15.221', 'admin', '2018-07-12 16:25:51', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('8', '117.159.15.221', 'admin', '2018-07-12 16:27:00', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('9', '117.159.15.221', 'admin', '2018-07-12 16:53:44', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('10', '117.159.15.221', 'admin', '2018-07-12 17:01:38', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('11', '117.159.15.221', 'admin', '2018-07-12 17:04:31', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('55', '117.159.15.221', 'admin', '2018-07-14 16:03:21', '河南省信阳市');
INSERT INTO `t_loginlog` VALUES ('56', '182.149.160.175', '110', '2019-12-10 10:05:04', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('57', '182.149.160.175', '110', '2019-12-10 10:05:06', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('58', '182.149.160.175', '110', '2019-12-10 10:06:34', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('59', '182.149.160.175', '110', '2019-12-10 10:20:56', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('60', '182.149.160.175', '110', '2019-12-10 10:25:51', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('61', '182.149.160.175', '110', '2019-12-10 10:50:20', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('62', '182.149.160.175', '110', '2019-12-10 11:02:01', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('63', '182.149.160.175', '110', '2019-12-10 14:43:31', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('64', '182.149.160.175', '110', '2019-12-11 09:42:25', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('65', '182.149.160.175', '110', '2019-12-11 10:12:56', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('66', '182.149.160.175', '110', '2019-12-11 10:25:37', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('67', '182.149.160.175', '12345', '2019-12-11 11:04:31', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('68', '182.149.160.175', '110', '2019-12-11 11:37:47', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('69', '182.149.160.175', '110', '2019-12-11 14:43:48', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('70', '182.149.160.175', '110', '2019-12-11 15:17:58', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('71', '182.149.160.175', '110', '2019-12-11 15:32:14', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('72', '182.149.160.175', '110', '2019-12-11 16:01:07', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('73', '182.149.160.175', '110', '2019-12-12 10:17:03', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('74', '182.149.160.175', '110', '2019-12-12 14:31:15', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('75', '182.149.160.175', '110', '2019-12-12 15:45:33', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('76', '182.149.160.175', '110', '2019-12-13 09:39:47', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('77', '182.149.160.175', '110', '2019-12-13 10:17:25', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('78', '182.149.160.175', '8888', '2019-12-13 11:19:25', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('79', '222.209.10.166', '110', '2019-12-17 14:40:40', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('80', '222.209.10.166', '110', '2019-12-17 15:05:35', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('81', '222.209.10.166', '110', '2019-12-17 15:51:53', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('82', '222.209.10.166', '110', '2019-12-17 16:20:17', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('83', '222.209.10.166', '110', '2019-12-17 16:21:15', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('84', '222.209.10.166', '110', '2019-12-17 16:23:10', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('85', '222.209.10.166', '110', '2019-12-17 16:25:09', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('86', '222.209.10.166', '110', '2019-12-17 16:29:31', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('87', '222.209.10.166', '110', '2019-12-17 16:34:44', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('88', '222.209.10.166', '1108888', '2019-12-18 11:02:05', '');
INSERT INTO `t_loginlog` VALUES ('89', '222.209.10.166', '9527888', '2019-12-18 11:02:38', '');
INSERT INTO `t_loginlog` VALUES ('90', '222.209.10.166', '1234588', '2019-12-18 11:04:41', '');
INSERT INTO `t_loginlog` VALUES ('91', '222.209.10.166', '8080808', '2019-12-18 11:27:21', '');
INSERT INTO `t_loginlog` VALUES ('92', '222.209.10.166', '8080808', '2019-12-18 11:31:22', '');
INSERT INTO `t_loginlog` VALUES ('93', '222.209.10.166', '8080808', '2019-12-18 11:32:24', '');
INSERT INTO `t_loginlog` VALUES ('94', '222.209.10.166', '1234588', '2019-12-18 11:33:45', '');
INSERT INTO `t_loginlog` VALUES ('95', '222.209.10.166', '1108888', '2019-12-18 11:34:21', '');
INSERT INTO `t_loginlog` VALUES ('96', '222.209.10.166', '8080808', '2019-12-18 14:28:32', '');
INSERT INTO `t_loginlog` VALUES ('97', '222.209.10.166', '1108888', '2019-12-18 14:29:04', '');
INSERT INTO `t_loginlog` VALUES ('98', '222.209.10.166', '1108888', '2019-12-18 15:02:11', '');
INSERT INTO `t_loginlog` VALUES ('99', '222.209.10.166', '1108888', '2019-12-18 15:41:25', '');
INSERT INTO `t_loginlog` VALUES ('100', '222.209.10.166', '8989898', '2019-12-18 15:42:37', '');
INSERT INTO `t_loginlog` VALUES ('101', '222.209.10.166', '1108888', '2019-12-18 15:43:42', '');
INSERT INTO `t_loginlog` VALUES ('102', '222.209.10.166', '1108888', '2019-12-18 15:48:22', '');
INSERT INTO `t_loginlog` VALUES ('103', '222.209.10.166', '1234588', '2019-12-18 15:49:58', '');
INSERT INTO `t_loginlog` VALUES ('104', '125.69.47.152', '1234', '2019-12-19 09:36:03', '');
INSERT INTO `t_loginlog` VALUES ('105', '125.69.47.152', '1234', '2019-12-19 11:05:56', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('106', '125.69.47.152', '1234', '2019-12-19 11:13:08', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('107', '125.69.47.152', '1234', '2019-12-19 11:15:10', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('108', '125.69.47.152', '1234588', '2019-12-19 11:15:55', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('109', '125.69.47.152', '1234588', '2019-12-19 11:21:04', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('110', '125.69.47.152', '1234588', '2019-12-19 11:40:20', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('111', '125.69.47.152', '1234588', '2019-12-19 11:41:29', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('112', '125.69.47.152', '1234588', '2019-12-19 11:46:36', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('113', '125.69.47.152', '1234588', '2019-12-19 15:22:25', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('114', '125.69.47.152', '1108888', '2019-12-19 15:38:55', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('115', '125.69.47.152', '1234588', '2019-12-19 15:46:58', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('116', '125.69.47.152', '1108888', '2019-12-19 15:47:32', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('117', '125.69.47.152', '1108888', '2019-12-19 15:54:25', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('118', '125.69.47.152', '1108888', '2019-12-19 15:57:40', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('119', '125.69.47.152', '1108888', '2019-12-19 16:29:14', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('120', '125.69.47.152', '1108888', '2019-12-19 16:36:58', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('121', '125.69.47.152', '1108888', '2019-12-19 16:58:49', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('122', '125.69.47.152', '1108888', '2019-12-19 16:59:59', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('123', '125.69.47.152', '1108888', '2019-12-19 17:06:28', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('124', '125.69.47.152', '1108888', '2019-12-19 17:10:43', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('125', '125.69.47.152', 'admin', '2019-12-20 14:23:55', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('126', '125.69.47.152', 'admin', '2019-12-20 14:25:23', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('127', '125.69.47.152', '9999', '2019-12-20 14:41:26', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('128', '125.69.47.152', '1234588', '2019-12-20 15:34:01', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('129', '125.69.47.152', '1234588', '2019-12-20 15:35:05', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('130', '125.69.47.152', '1234588', '2019-12-20 15:36:14', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('131', '125.69.47.152', '1234588', '2019-12-20 15:37:35', '四川省,成都市');
INSERT INTO `t_loginlog` VALUES ('132', '171.214.216.74', '1108888', '2020-01-01 12:49:16', '四川省,成都市');

-- ----------------------------
-- Table structure for t_major
-- ----------------------------
DROP TABLE IF EXISTS `t_major`;
CREATE TABLE `t_major` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `major_name` varchar(20) DEFAULT NULL,
  `major_time` varchar(20) DEFAULT NULL,
  `major_date` date DEFAULT NULL,
  `major_type` int(6) DEFAULT NULL,
  `major_delete` int(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_major_id` (`major_type`),
  CONSTRAINT `FK_major_id` FOREIGN KEY (`major_type`) REFERENCES `t_majortype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_major
-- ----------------------------
INSERT INTO `t_major` VALUES ('1', '物联网', '40', '2019-08-02', '1', '0');
INSERT INTO `t_major` VALUES ('2', '商务外语', '200', '2019-08-08', '2', '0');
INSERT INTO `t_major` VALUES ('3', '计算机专业', '500', '2019-12-12', '2', '0');

-- ----------------------------
-- Table structure for t_majortype
-- ----------------------------
DROP TABLE IF EXISTS `t_majortype`;
CREATE TABLE `t_majortype` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `majortype` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_majortype
-- ----------------------------
INSERT INTO `t_majortype` VALUES ('1', '精品');
INSERT INTO `t_majortype` VALUES ('2', '业余');
INSERT INTO `t_majortype` VALUES ('3', '普通');

-- ----------------------------
-- Table structure for t_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission` (
  `p_id` int(6) NOT NULL AUTO_INCREMENT,
  `p_icon` varchar(255) DEFAULT NULL,
  `p_name` varchar(255) DEFAULT NULL,
  `p_parentid` int(6) DEFAULT NULL,
  `p_url` varchar(255) DEFAULT NULL,
  `p_type` varchar(255) DEFAULT NULL,
  `p_delete` int(6) DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES ('1', 'layui-icon layui-icon-app', '我的工具', '0', null, 'menu', '0');
INSERT INTO `t_permission` VALUES ('2', null, '我的日历', '1', '/page_clock', 'menu', '0');
INSERT INTO `t_permission` VALUES ('3', null, '天气查询', '1', '/page_weather', 'menu', '0');
INSERT INTO `t_permission` VALUES ('4', null, '地图查询', '1', '/page_map', 'menu', '0');
INSERT INTO `t_permission` VALUES ('5', 'fa fa-sitemap', '部门管理', '0', null, 'menu', '0');
INSERT INTO `t_permission` VALUES ('6', null, '部门列表', '5', '/depart_list/1/5', 'menu', '0');
INSERT INTO `t_permission` VALUES ('7', null, '部门新增', '5', '/page_departadd', 'menu', '0');
INSERT INTO `t_permission` VALUES ('8', 'layui-icon layui-icon-user', '员工管理', '0', null, 'menu', '0');
INSERT INTO `t_permission` VALUES ('9', null, '员工列表', '8', '/emp_list/1/5', 'menu', '0');
INSERT INTO `t_permission` VALUES ('10', null, '员工新增', '8', '/page_empadd', 'menu', '0');
INSERT INTO `t_permission` VALUES ('11', '', '员工报表', '8', '/emp_getTongjiData', 'menu', '0');
INSERT INTO `t_permission` VALUES ('12', 'fa fa-graduation-cap', '专业管理', '0', null, 'menu', '0');
INSERT INTO `t_permission` VALUES ('13', null, '专业列表', '12', 'courselist.html', 'menu', '0');
INSERT INTO `t_permission` VALUES ('14', null, '专业新增', '12', 'XXXX', 'menu', '0');
INSERT INTO `t_permission` VALUES ('15', 'fa fa-cube', '班级管理', '0', null, 'menu', '0');
INSERT INTO `t_permission` VALUES ('16', null, '班级列表', '15', 'gradelist.html', 'menu', '0');
INSERT INTO `t_permission` VALUES ('17', null, '班级新增', '15', '/page_gradeadd', 'menu', '0');
INSERT INTO `t_permission` VALUES ('18', 'fa fa-user-secret', '学生管理', '0', null, 'menu', '0');
INSERT INTO `t_permission` VALUES ('19', null, '学生列表', '18', '/student_list/1/5', 'menu', '0');
INSERT INTO `t_permission` VALUES ('20', null, '学生新增', '18', 'studentadd.html', 'menu', '0');
INSERT INTO `t_permission` VALUES ('21', null, '学生导入', '18', '/page_studentbatch', 'menu', '0');
INSERT INTO `t_permission` VALUES ('22', null, '员工查看', null, 'emp:query', 'permission', '0');
INSERT INTO `t_permission` VALUES ('23', null, '员工编辑', null, 'emp:edit', 'permission', '0');
INSERT INTO `t_permission` VALUES ('24', null, '员工删除', null, 'emp:delete', 'permission', '0');
INSERT INTO `t_permission` VALUES ('25', null, '员工新增', null, 'emp:add', 'permission', '0');
INSERT INTO `t_permission` VALUES ('26', null, '部门查看', null, 'dept:query', 'permission', '0');
INSERT INTO `t_permission` VALUES ('27', null, '部门新增', null, 'dept:add', 'permission', '0');
INSERT INTO `t_permission` VALUES ('28', null, '部门删除', null, 'dept:delete', 'permission', '0');
INSERT INTO `t_permission` VALUES ('29', null, '部门编辑', null, 'dept:edit', 'permission', '0');
INSERT INTO `t_permission` VALUES ('30', null, '我的日历', null, 'tools:clock', 'permission', '0');
INSERT INTO `t_permission` VALUES ('31', null, '我的天气', null, 'tools:weather', 'permission', '0');
INSERT INTO `t_permission` VALUES ('32', null, '我的地图', null, 'tools:map', 'permission', '0');
INSERT INTO `t_permission` VALUES ('33', null, '员工报表', null, 'emp:baobiao', 'permission', '0');
INSERT INTO `t_permission` VALUES ('34', null, '学生列表', null, 'student:query', 'permission', '0');
INSERT INTO `t_permission` VALUES ('35', null, '学生导出', null, 'student:exportExcel', 'permission', '0');

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `r_id` int(8) NOT NULL AUTO_INCREMENT,
  `r_name` varchar(200) DEFAULT NULL,
  `r_delete` int(6) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', '超级管理员', '0');
INSERT INTO `t_role` VALUES ('2', '管理员', '0');
INSERT INTO `t_role` VALUES ('3', '普通员工', '0');
INSERT INTO `t_role` VALUES ('4', '教务', '0');

-- ----------------------------
-- Table structure for t_role_permission
-- ----------------------------
DROP TABLE IF EXISTS `t_role_permission`;
CREATE TABLE `t_role_permission` (
  `role_permission_id` int(6) NOT NULL AUTO_INCREMENT,
  `role_id` int(6) DEFAULT NULL,
  `permission_id` int(6) DEFAULT NULL,
  PRIMARY KEY (`role_permission_id`),
  KEY `fk_permission_id` (`permission_id`),
  KEY `fk_role_id123` (`role_id`),
  CONSTRAINT `fk_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `t_permission` (`p_id`),
  CONSTRAINT `fk_role_id123` FOREIGN KEY (`role_id`) REFERENCES `t_role` (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_role_permission
-- ----------------------------
INSERT INTO `t_role_permission` VALUES ('1', '1', '1');
INSERT INTO `t_role_permission` VALUES ('2', '1', '2');
INSERT INTO `t_role_permission` VALUES ('3', '1', '3');
INSERT INTO `t_role_permission` VALUES ('4', '1', '4');
INSERT INTO `t_role_permission` VALUES ('5', '1', '5');
INSERT INTO `t_role_permission` VALUES ('6', '1', '6');
INSERT INTO `t_role_permission` VALUES ('7', '1', '7');
INSERT INTO `t_role_permission` VALUES ('8', '1', '8');
INSERT INTO `t_role_permission` VALUES ('9', '1', '9');
INSERT INTO `t_role_permission` VALUES ('10', '1', '10');
INSERT INTO `t_role_permission` VALUES ('11', '1', '11');
INSERT INTO `t_role_permission` VALUES ('12', '1', '12');
INSERT INTO `t_role_permission` VALUES ('13', '1', '13');
INSERT INTO `t_role_permission` VALUES ('14', '1', '14');
INSERT INTO `t_role_permission` VALUES ('15', '1', '15');
INSERT INTO `t_role_permission` VALUES ('16', '1', '16');
INSERT INTO `t_role_permission` VALUES ('17', '1', '17');
INSERT INTO `t_role_permission` VALUES ('18', '1', '18');
INSERT INTO `t_role_permission` VALUES ('19', '1', '19');
INSERT INTO `t_role_permission` VALUES ('20', '1', '20');
INSERT INTO `t_role_permission` VALUES ('21', '1', '21');
INSERT INTO `t_role_permission` VALUES ('22', '2', '1');
INSERT INTO `t_role_permission` VALUES ('23', '2', '2');
INSERT INTO `t_role_permission` VALUES ('24', '2', '3');
INSERT INTO `t_role_permission` VALUES ('25', '2', '4');
INSERT INTO `t_role_permission` VALUES ('26', '2', '5');
INSERT INTO `t_role_permission` VALUES ('27', '2', '6');
INSERT INTO `t_role_permission` VALUES ('28', '2', '7');
INSERT INTO `t_role_permission` VALUES ('29', '2', '8');
INSERT INTO `t_role_permission` VALUES ('30', '2', '9');
INSERT INTO `t_role_permission` VALUES ('31', '2', '10');
INSERT INTO `t_role_permission` VALUES ('32', '2', '11');
INSERT INTO `t_role_permission` VALUES ('34', '3', '2');
INSERT INTO `t_role_permission` VALUES ('35', '3', '3');
INSERT INTO `t_role_permission` VALUES ('36', '3', '4');
INSERT INTO `t_role_permission` VALUES ('37', '3', '5');
INSERT INTO `t_role_permission` VALUES ('38', '3', '6');
INSERT INTO `t_role_permission` VALUES ('39', '3', '8');
INSERT INTO `t_role_permission` VALUES ('40', '3', '9');
INSERT INTO `t_role_permission` VALUES ('41', '4', '1');
INSERT INTO `t_role_permission` VALUES ('42', '4', '2');
INSERT INTO `t_role_permission` VALUES ('43', '4', '3');
INSERT INTO `t_role_permission` VALUES ('44', '4', '4');
INSERT INTO `t_role_permission` VALUES ('45', '4', '15');
INSERT INTO `t_role_permission` VALUES ('46', '4', '16');
INSERT INTO `t_role_permission` VALUES ('47', '4', '17');
INSERT INTO `t_role_permission` VALUES ('48', '4', '18');
INSERT INTO `t_role_permission` VALUES ('49', '4', '19');
INSERT INTO `t_role_permission` VALUES ('50', '4', '20');
INSERT INTO `t_role_permission` VALUES ('51', '4', '21');
INSERT INTO `t_role_permission` VALUES ('57', '3', '31');
INSERT INTO `t_role_permission` VALUES ('59', '3', '32');
INSERT INTO `t_role_permission` VALUES ('60', '3', '26');
INSERT INTO `t_role_permission` VALUES ('63', '1', '26');
INSERT INTO `t_role_permission` VALUES ('64', '1', '27');
INSERT INTO `t_role_permission` VALUES ('65', '1', '28');
INSERT INTO `t_role_permission` VALUES ('66', '1', '29');
INSERT INTO `t_role_permission` VALUES ('67', '1', '22');
INSERT INTO `t_role_permission` VALUES ('68', '1', '23');
INSERT INTO `t_role_permission` VALUES ('69', '1', '24');
INSERT INTO `t_role_permission` VALUES ('70', '1', '25');
INSERT INTO `t_role_permission` VALUES ('71', '1', '33');
INSERT INTO `t_role_permission` VALUES ('72', '1', '34');
INSERT INTO `t_role_permission` VALUES ('73', '1', '35');
INSERT INTO `t_role_permission` VALUES ('75', '3', '1');

-- ----------------------------
-- Table structure for t_student
-- ----------------------------
DROP TABLE IF EXISTS `t_student`;
CREATE TABLE `t_student` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `no` varchar(20) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `cardno` varchar(20) DEFAULT NULL,
  `school` varchar(50) DEFAULT NULL,
  `education` varchar(20) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL COMMENT '外键 和班级主键有关系',
  `flag` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `qq` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `createdate` date DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `del` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_student_class_id` (`class_id`),
  CONSTRAINT `FK_student_class_id` FOREIGN KEY (`class_id`) REFERENCES `t_class` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_student
-- ----------------------------
INSERT INTO `t_student` VALUES ('1', 'qf000002', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '1', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('2', 'qf000003', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '1', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('3', 'qf000004', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '2', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('5', 'qf000006', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '2', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('6', 'qf000007', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '1', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('7', 'qf000008', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '2', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('8', 'qf000011', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '1', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('9', 'qf000021', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '2', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('10', 'qf000023', '小王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '2', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('11', 'qf000028', '老王', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '4', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('12', 'qf000027', '王二小', '男', '1998-03-20', '321721199803203212', '郑州大学', '本科', '4', '1', 'zhansgan@163.com', '222321', '110', '2018-03-03', 'photos\\e49c64f2-0df8-464c-93ad-7ab95fb7867e_cw1.jpg', '0');
INSERT INTO `t_student` VALUES ('13', '8991', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342342@qq.com', '133456546', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('14', '8992', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342343@qq.com', '133456547', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('15', '8993', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342344@qq.com', '133456548', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('16', '8994', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342345@qq.com', '133456549', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('17', '8995', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342346@qq.com', '133456550', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('18', '8996', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342347@qq.com', '133456551', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('19', '8997', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342348@qq.com', '133456552', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('20', '8998', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342349@qq.com', '133456553', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('21', '8999', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342350@qq.com', '133456554', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('22', '9000', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342351@qq.com', '133456555', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('23', '9001', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342352@qq.com', '133456556', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('24', '9002', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342353@qq.com', '133456557', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('25', '9003', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342354@qq.com', '133456558', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('26', '9004', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342355@qq.com', '133456559', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('27', '9005', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342356@qq.com', '133456560', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('28', '9006', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342357@qq.com', '133456561', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('29', '9007', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342358@qq.com', '133456562', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('30', '9008', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342359@qq.com', '133456563', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('31', '9009', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342360@qq.com', '133456564', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('32', '9010', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342361@qq.com', '133456565', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('33', '9011', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342362@qq.com', '133456566', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('34', '9012', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342363@qq.com', '133456567', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('35', '9013', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342364@qq.com', '133456568', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('36', '9014', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342365@qq.com', '133456569', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('37', '9015', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342366@qq.com', '133456570', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('38', '9016', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342367@qq.com', '133456571', null, '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('39', '8991', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342342@qq.com', null, '133456546', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('40', '8992', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342343@qq.com', null, '133456547', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('41', '8993', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342344@qq.com', null, '133456548', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('42', '8994', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342345@qq.com', null, '133456549', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('43', '8995', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342346@qq.com', null, '133456550', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('44', '8996', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342347@qq.com', null, '133456551', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('45', '8997', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342348@qq.com', null, '133456552', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('46', '8998', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342349@qq.com', null, '133456553', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('47', '8999', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342350@qq.com', null, '133456554', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('48', '9000', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342351@qq.com', null, '133456555', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('49', '9001', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342352@qq.com', null, '133456556', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('50', '9002', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342353@qq.com', null, '133456557', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('51', '9003', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342354@qq.com', null, '133456558', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('52', '9004', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342355@qq.com', null, '133456559', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('53', '9005', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342356@qq.com', null, '133456560', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('54', '9006', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342357@qq.com', null, '133456561', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('55', '9007', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342358@qq.com', null, '133456562', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('56', '9008', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342359@qq.com', null, '133456563', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('57', '9009', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342360@qq.com', null, '133456564', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('58', '9010', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342361@qq.com', null, '133456565', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('59', '9011', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342362@qq.com', null, '133456566', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('60', '9012', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342363@qq.com', null, '133456567', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('61', '9013', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342364@qq.com', null, '133456568', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('62', '9014', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342365@qq.com', null, '133456569', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('63', '9015', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342366@qq.com', null, '133456570', '2019-12-13', null, '0');
INSERT INTO `t_student` VALUES ('64', '9016', '小三', '男', null, null, '哈佛大学', null, '4', '1', '342367@qq.com', null, '133456571', '2019-12-13', null, '0');
