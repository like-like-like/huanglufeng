package com.bruceliu.service.impl;

import com.bruceliu.mapper.StudentMapper;
import com.bruceliu.pojo.Student;
import com.bruceliu.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/12 10:02
 * @QQ:1241488705
 * @Description:
 */
@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    StudentMapper studentMapper;


    @Override
    public int getTotalCount(Map<String, Object> map) {
        return studentMapper.getTotalCount(map);
    }

    @Override
    public List<Student> getStudents(Map<String, Object> map) {
        return studentMapper.getStudents(map);
    }
}
