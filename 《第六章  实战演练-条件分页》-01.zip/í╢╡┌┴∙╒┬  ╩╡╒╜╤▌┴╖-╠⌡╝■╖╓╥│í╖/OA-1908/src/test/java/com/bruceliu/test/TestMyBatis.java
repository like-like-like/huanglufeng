package com.bruceliu.test;

import com.alibaba.fastjson.JSONObject;
import com.bruceliu.mapper.DepartMapper;
import com.bruceliu.mapper.EmpMapper;
import com.bruceliu.pojo.Depart;
import com.bruceliu.pojo.Emp;
import com.bruceliu.utils.TongJi;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.ls.LSInput;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/9 10:58
 * @QQ:1241488705
 * @Description:
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestMyBatis {

    @Autowired
    EmpMapper empMapper;

    @Resource
    DepartMapper departMapper;

    @Test
    public void testDept(){
        List<String> dnames=new ArrayList<String>();
        List<Depart> departs = departMapper.findDeparts();
        for (Depart depart : departs) {
            dnames.add(depart.getName());
        }
        //把数组转JSON
        String jsonString = JSONObject.toJSONString(dnames);
        System.out.println(jsonString);
    }

    @Test
    public void testgetEmpsTongji(){
        List<TongJi> tongjis = empMapper.getEmpsTongji();
        for (TongJi tongji : tongjis) {
            System.out.println(tongji);
        }
        //把数组转JSON
        String jsonString = JSONObject.toJSONString(tongjis);
        System.out.println(jsonString);
    }


    @Test
    public void testLogin(){
        Emp emp=new Emp();
        emp.setNo("qf000001");
        emp.setPass("admin");
        Emp emp1 = empMapper.login(emp);
        System.out.println(emp1);
    }

    @Test
    public void testAddDepart(){
        for (int i = 1; i <=100 ; i++) {
            Depart depart=new Depart();
            depart.setName("部门测试"+i);
            depart.setCreatetime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            departMapper.addDepart(depart);
        }
    }

    @Test
    public void testEmps(){
        List<Emp> emps = empMapper.getEmps(0, 5);
        for (Emp emp : emps) {
            System.out.println(emp);
        }
    }

}
