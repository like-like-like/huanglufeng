package com.bruceliu.mapper;

import com.bruceliu.pojo.Depart;
import com.bruceliu.pojo.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/12 09:46
 * @QQ:1241488705
 * @Description:
 */
public interface StudentMapper {

    /**
     * 01-查询总数
     * @return
     */
    public int getTotalCount(Map<String,Object> map);

    /**
     * 02-查询每页数据
     * @return
     */
    public List<Student> getStudents(Map<String,Object> map);
}
