package com.bruceliu.controller;

import com.alibaba.fastjson.JSONObject;
import com.bruceliu.pojo.Depart;
import com.bruceliu.pojo.Emp;
import com.bruceliu.pojo.Loginlog;
import com.bruceliu.service.DepartService;
import com.bruceliu.service.EmpService;
import com.bruceliu.service.LoginlogService;
import com.bruceliu.utils.PageUtils;
import com.bruceliu.utils.ResultMessage;
import com.bruceliu.utils.TongJi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: bruceliu
 * @Date: 2019/12/9 11:06
 * @QQ:1241488705
 * @Description:
 */
@Controller
@Scope("prototype")
public class EmpController {

    @Autowired
    EmpService empService;

    @Autowired
    DepartService departService;

    @Autowired
    LoginlogService loginlogService;

    /**
     * 01-获取统计数据
     */
    @RequestMapping("/emp_getTongjiData")
    public String getTongjiData(Model model){
        List<String> dnames=new ArrayList<String>();
        List<Depart> departs = departService.findDeparts();
        for (Depart depart : departs) {
            dnames.add(depart.getName());
        }
        String jsonDnames = JSONObject.toJSONString(dnames);

        List<TongJi> tongjis = empService.getEmpsTongji();
        String jsonCounts = JSONObject.toJSONString(tongjis);

        model.addAttribute("jsonDnames",jsonDnames);
        model.addAttribute("jsonCounts",jsonCounts);
        return "empcount";
    }


    /**
     * 01-分页
     * /emp_list/1/5
     * @return
     */
    @RequestMapping("/emp_list/{pageIndex}/{pageSize}")
    public String depart_list(@PathVariable("pageIndex") long pageIndex, @PathVariable("pageSize") long pageSize, Model model){
        int totalCount = empService.getTotalCount(); //总条数
        List<Emp> emps = empService.getEmps((pageIndex - 1) * pageSize, pageSize);//每页数据
        //封装一个分页的工具类
        PageUtils pageUtils=new PageUtils(pageIndex,pageSize,totalCount,emps);
        model.addAttribute("pageUtils",pageUtils);
        return "emplist";
    }

    @ResponseBody
    @RequestMapping("/emp_add")
    public ResultMessage addEmp(Emp emp){
        ResultMessage requestMessage = null;
        int count = empService.addEmp(emp);
        if (count > 0) {
            requestMessage = new ResultMessage(200, "员工添加成功");
        } else {
            requestMessage = new ResultMessage(500, "员工添加失败");
        }
        return  requestMessage;
    }

    @RequestMapping("/emp_login")
    @ResponseBody//将返回值自动转化为JSON
    public ResultMessage login(Emp emp,String ip,String cityAndAddress, HttpServletResponse response, HttpSession session) throws Exception {
        System.out.println("ip："+ip);
        System.out.println("cityAndAddress："+cityAndAddress);
        ResultMessage message = null;
        response.setContentType("text/html;charset=utf-8");
        System.out.println("要登录的对象是:" + emp);
        Emp loginEmp = empService.login(emp);
        if (loginEmp != null) {
            if (loginEmp.getFlag() == 1) {
                //登录成功去重定向首页
                //response.sendRedirect("index.jsp");
                //存session
                session.setAttribute("loginEmp",loginEmp);
                //存储用户登录的日志信息
                Loginlog loginlog=new Loginlog(ip,emp.getNo(),cityAndAddress);
                int count = loginlogService.addLoginLog(loginlog);
                System.out.println(count>0?"日志新增成功":"日志新增失败");
                message = new ResultMessage(200, "登录成功");
            } else {
                //response.getWriter().write("<script>alert('账号已经被禁用，请联系管理员!');location.href='login.jsp';</script>");
                message = new ResultMessage(300, "账号已经被禁用，请联系管理员!");
            }
        } else {
            //response.getWriter().write("<script>alert('账号或密码错误!');location.href='login.jsp';</script>");
            message = new ResultMessage(500, "账号或密码错误!");
        }
        //把message对象使用工具，转为JSON字符串，不用人工拼接
        return message;
    }

    @ResponseBody //返回值转JSON
    @RequestMapping("/getLoginlogs")
    public List<Loginlog> getLoginlogs(HttpSession session){
        return loginlogService.getLastestLog(((Emp)session.getAttribute("loginEmp")).getNo());
    }
}
